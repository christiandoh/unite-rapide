--
-- PostgreSQL database dump
--

\restrict waGw4ao9bPgsgW0Gd6T9a8nFcF2h5oXBCQ5UeMZChy9VpYevMP5DL7eqkpd6ERq

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."Role" AS ENUM (
    'user',
    'admin'
);


ALTER TYPE public."Role" OWNER TO ussd_admin;

--
-- Name: SeveriteLog; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."SeveriteLog" AS ENUM (
    'debug',
    'info',
    'warning',
    'error',
    'critical'
);


ALTER TYPE public."SeveriteLog" OWNER TO ussd_admin;

--
-- Name: StatutCommande; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutCommande" AS ENUM (
    'en_attente_paiement',
    'paiement_soumis',
    'paiement_valide',
    'paiement_rejete',
    'en_cours_execution',
    'execute',
    'echoue',
    'rembourse'
);


ALTER TYPE public."StatutCommande" OWNER TO ussd_admin;

--
-- Name: StatutExecution; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutExecution" AS ENUM (
    'en_attente',
    'en_cours',
    'reussi',
    'echoue',
    'timeout',
    'annule'
);


ALTER TYPE public."StatutExecution" OWNER TO ussd_admin;

--
-- Name: StatutPhone; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutPhone" AS ENUM (
    'en_ligne',
    'hors_ligne',
    'occupe',
    'maintenance',
    'erreur'
);


ALTER TYPE public."StatutPhone" OWNER TO ussd_admin;

--
-- Name: StatutUser; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutUser" AS ENUM (
    'actif',
    'suspendu',
    'banni'
);


ALTER TYPE public."StatutUser" OWNER TO ussd_admin;

--
-- Name: StatutValidation; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutValidation" AS ENUM (
    'en_attente',
    'valide_auto',
    'valide_manuel',
    'rejete',
    'a_reviser'
);


ALTER TYPE public."StatutValidation" OWNER TO ussd_admin;

--
-- Name: TypeService; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."TypeService" AS ENUM (
    'forfait_internet',
    'credit_appel',
    'forfait_mixte',
    'abonnement'
);


ALTER TYPE public."TypeService" OWNER TO ussd_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO ussd_admin;

--
-- Name: commandes; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.commandes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    service_id uuid NOT NULL,
    telephone_beneficiaire character varying(20) NOT NULL,
    reference_unique character varying(20) NOT NULL,
    montant numeric(10,2) NOT NULL,
    lien_paiement_wave text NOT NULL,
    statut_commande character varying(30) DEFAULT 'en_attente_paiement'::character varying NOT NULL,
    date_expiration_paiement timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.commandes OWNER TO ussd_admin;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    titre character varying(255) NOT NULL,
    message text NOT NULL,
    lu boolean DEFAULT false NOT NULL,
    donnees jsonb DEFAULT '{}'::jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notifications OWNER TO ussd_admin;

--
-- Name: operateurs; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.operateurs (
    id uuid NOT NULL,
    nom character varying(50) NOT NULL,
    code_pays character varying(5) DEFAULT '+225'::character varying NOT NULL,
    prefixe character varying(10),
    logo_url character varying(255),
    actif boolean DEFAULT true NOT NULL
);


ALTER TABLE public.operateurs OWNER TO ussd_admin;

--
-- Name: preuves_paiement; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.preuves_paiement (
    id uuid NOT NULL,
    commande_id uuid NOT NULL,
    image_originale_url text NOT NULL,
    image_traitee_url text,
    donnees_extraites jsonb,
    score_confiance numeric(5,2),
    flags_fraude jsonb DEFAULT '[]'::jsonb,
    statut_validation character varying(30) DEFAULT 'en_attente'::character varying NOT NULL,
    valide_par uuid,
    commentaire_validation text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.preuves_paiement OWNER TO ussd_admin;

--
-- Name: services_catalogue; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.services_catalogue (
    id uuid NOT NULL,
    operateur_id uuid NOT NULL,
    nom character varying(255) NOT NULL,
    description text,
    type_service character varying(50) NOT NULL,
    code_ussd character varying(20) NOT NULL,
    sequence_ussd jsonb NOT NULL,
    montant_wave numeric(10,2) NOT NULL,
    volume_data character varying(50),
    duree_validite character varying(50),
    temps_execution_moyen integer DEFAULT 30 NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    populaire boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.services_catalogue OWNER TO ussd_admin;

--
-- Name: taches_ussd; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.taches_ussd (
    id uuid NOT NULL,
    commande_id uuid NOT NULL,
    telephone_executeur_id uuid,
    priorite integer DEFAULT 5 NOT NULL,
    statut_execution character varying(30) DEFAULT 'en_attente'::character varying NOT NULL,
    logs_execution jsonb DEFAULT '[]'::jsonb,
    nombre_tentatives integer DEFAULT 0 NOT NULL,
    tentative_max integer DEFAULT 3 NOT NULL,
    date_debut_execution timestamp(3) without time zone,
    date_fin_execution timestamp(3) without time zone,
    message_erreur text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.taches_ussd OWNER TO ussd_admin;

--
-- Name: telephones_executeurs; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.telephones_executeurs (
    id uuid NOT NULL,
    nom_appareil character varying(100) NOT NULL,
    modele character varying(100),
    numero_telephone character varying(20) NOT NULL,
    operateur_id uuid NOT NULL,
    token_auth character varying(255) NOT NULL,
    statut character varying(20) DEFAULT 'hors_ligne'::character varying NOT NULL,
    niveau_batterie integer,
    force_signal integer,
    version_app character varying(20),
    derniere_connexion timestamp(3) without time zone,
    ip_address character varying(45),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.telephones_executeurs OWNER TO ussd_admin;

--
-- Name: transactions_logs; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.transactions_logs (
    id uuid NOT NULL,
    type_evenement character varying(50) NOT NULL,
    severite character varying(20) DEFAULT 'info'::character varying NOT NULL,
    details jsonb DEFAULT '{}'::jsonb,
    user_id uuid,
    commande_id uuid,
    adresse_ip character varying(45),
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transactions_logs OWNER TO ussd_admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    nom character varying(100) NOT NULL,
    prenom character varying(100),
    telephone character varying(20) NOT NULL,
    email character varying(255),
    mot_de_passe_hash character varying(255) NOT NULL,
    email_verifie boolean DEFAULT false NOT NULL,
    telephone_verifie boolean DEFAULT false NOT NULL,
    statut character varying(20) DEFAULT 'actif'::character varying NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying NOT NULL,
    derniere_connexion timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO ussd_admin;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.


--
-- Data for Name: commandes; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.commandes (id, user_id, service_id, telephone_beneficiaire, reference_unique, montant, lien_paiement_wave, statut_commande, date_expiration_paiement, created_at, updated_at) FROM stdin;
e9c0326c-9ebe-45a8-ba48-09eaa15485b6	9297f835-1625-4997-937c-b08fee57f211	9339c060-b94c-4508-a584-f8d03b08213b	0700000001	USSD-20260519-GA1L59	2000.00	https://pay.wave.com/m/M_ci_vaaCd-Y6Joie/c/ci/?amount=2000	en_attente_paiement	2026-05-19 02:02:32.841	2026-05-19 01:47:32.843	2026-05-19 01:47:32.843
d5272ddb-b90a-46e2-b209-95f19f22dbc5	9297f835-1625-4997-937c-b08fee57f211	9339c060-b94c-4508-a584-f8d03b08213b	0700000001	USSD-20260519-TEJAAD	2000.00	https://pay.wave.com/m/M_ci_vaaCd-Y6Joie/c/ci/?amount=2000	en_attente_paiement	2026-05-19 02:03:58.415	2026-05-19 01:48:58.416	2026-05-19 01:48:58.416
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.notifications (id, user_id, type, titre, message, lu, donnees, created_at) FROM stdin;
\.


--
-- Data for Name: operateurs; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.operateurs (id, nom, code_pays, prefixe, logo_url, actif) FROM stdin;
6eadd4e0-af00-4570-82da-8e54a5b08a45	Orange	+225	07	\N	t
d9840923-9926-429d-bac1-d4e7f4fb84cd	MTN	+225	05	\N	t
28bbbfd9-8567-43ff-9bce-9a6dad6a4687	Moov	+225	01	\N	t
\.


--
-- Data for Name: preuves_paiement; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.preuves_paiement (id, commande_id, image_originale_url, image_traitee_url, donnees_extraites, score_confiance, flags_fraude, statut_validation, valide_par, commentaire_validation, created_at) FROM stdin;
\.


--
-- Data for Name: services_catalogue; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.services_catalogue (id, operateur_id, nom, description, type_service, code_ussd, sequence_ussd, montant_wave, volume_data, duree_validite, temps_execution_moyen, actif, populaire, created_at) FROM stdin;
4ba3d8dd-c3c2-409f-b8d3-651f65437477	6eadd4e0-af00-4570-82da-8e54a5b08a45	Internet 2Go	\N	forfait_internet	*143*1#	["1", "2", "1"]	2000.00	2Go	7 jours	30	t	t	2026-05-19 01:47:06.636
0e88397a-d632-487a-9429-d0bf18a18237	6eadd4e0-af00-4570-82da-8e54a5b08a45	Internet 10Go	\N	forfait_internet	*143*1#	["1", "5", "1"]	10000.00	10Go	30 jours	30	t	t	2026-05-19 01:47:06.636
5caf3763-c4ee-456e-b076-27533f9fb0b9	6eadd4e0-af00-4570-82da-8e54a5b08a45	Crédit 5000F	\N	credit_appel	*144*1#	["1", "3"]	5000.00	\N	\N	30	t	t	2026-05-19 01:47:06.636
ebdfe1d9-cfb6-4b44-8e47-6fca9155172a	6eadd4e0-af00-4570-82da-8e54a5b08a45	Internet 500Mo	\N	forfait_internet	*143*1#	["1", "1", "1"]	500.00	500Mo	24 heures	30	t	f	2026-05-19 01:47:06.636
5c8b5573-1e5f-4f18-ab3d-d4b3bcbe8170	d9840923-9926-429d-bac1-d4e7f4fb84cd	Forfait 3Go	\N	forfait_internet	*133*1#	["1", "3", "2"]	3000.00	3Go	14 jours	30	t	t	2026-05-19 01:47:06.636
458a9b5f-0460-44d7-bc87-8101e1b3986e	d9840923-9926-429d-bac1-d4e7f4fb84cd	Crédit 10000F	\N	credit_appel	*136*1#	["1", "5"]	10000.00	\N	\N	30	t	t	2026-05-19 01:47:06.636
3cfbf030-4484-44f7-83ac-6ce498f9f046	d9840923-9926-429d-bac1-d4e7f4fb84cd	Forfait 1Go	\N	forfait_internet	*133*1#	["1", "1", "1"]	1000.00	1Go	7 jours	30	t	f	2026-05-19 01:47:06.636
9339c060-b94c-4508-a584-f8d03b08213b	28bbbfd9-8567-43ff-9bce-9a6dad6a4687	Forfait 2Go	\N	forfait_internet	*123*1#	["1", "2", "1"]	2000.00	2Go	7 jours	30	t	f	2026-05-19 01:47:06.636
877a06ca-a60c-4a2d-be97-f0678410f33e	28bbbfd9-8567-43ff-9bce-9a6dad6a4687	Crédit 2000F	\N	forfait_internet	*155#	["9", "4", "1", "5", "1", "0003"]	2000.00			30	t	t	2026-05-19 01:47:06.636
\.


--
-- Data for Name: taches_ussd; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.taches_ussd (id, commande_id, telephone_executeur_id, priorite, statut_execution, logs_execution, nombre_tentatives, tentative_max, date_debut_execution, date_fin_execution, message_erreur, created_at) FROM stdin;
\.


--
-- Data for Name: telephones_executeurs; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.telephones_executeurs (id, nom_appareil, modele, numero_telephone, operateur_id, token_auth, statut, niveau_batterie, force_signal, version_app, derniere_connexion, ip_address, created_at) FROM stdin;
ee104ef6-6d38-4a8a-9f74-69d4fc2550b8	MVCI01	Android	0103961828	28bbbfd9-8567-43ff-9bce-9a6dad6a4687	phone-mvci01-mpbz7ovt	hors_ligne	\N	\N	\N	\N	\N	2026-05-19 01:50:41.85
\.


--
-- Data for Name: transactions_logs; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.transactions_logs (id, type_evenement, severite, details, user_id, commande_id, adresse_ip, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.users (id, nom, prenom, telephone, email, mot_de_passe_hash, email_verifie, telephone_verifie, statut, role, derniere_connexion, created_at, updated_at) FROM stdin;
9297f835-1625-4997-937c-b08fee57f211	Test	User	0700000001	test@test.com	$2b$12$YJXr0qkQoTXTCcnbledIKuqoIxzdiqFxblXSzz5ObEN8FzMU2.DIW	f	f	actif	user	\N	2026-05-19 01:47:16.117	2026-05-19 01:47:16.117
dc7727e4-98bb-4491-ac3e-1c00b316aa2b	Admin	Super	0700000000	christiandoh29@gmail.com	$2b$12$bqNIRYS3UInSQZDWOQFGUeYAVb2sFNwgP90ZU7NW4noO0HeM6C8/u	f	f	actif	admin	2026-05-19 01:47:26.603	2026-05-19 01:47:06.59	2026-05-19 01:47:26.605
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: commandes commandes_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.commandes
    ADD CONSTRAINT commandes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: operateurs operateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.operateurs
    ADD CONSTRAINT operateurs_pkey PRIMARY KEY (id);


--
-- Name: preuves_paiement preuves_paiement_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.preuves_paiement
    ADD CONSTRAINT preuves_paiement_pkey PRIMARY KEY (id);


--
-- Name: services_catalogue services_catalogue_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.services_catalogue
    ADD CONSTRAINT services_catalogue_pkey PRIMARY KEY (id);


--
-- Name: taches_ussd taches_ussd_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.taches_ussd
    ADD CONSTRAINT taches_ussd_pkey PRIMARY KEY (id);


--
-- Name: telephones_executeurs telephones_executeurs_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.telephones_executeurs
    ADD CONSTRAINT telephones_executeurs_pkey PRIMARY KEY (id);


--
-- Name: transactions_logs transactions_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.transactions_logs
    ADD CONSTRAINT transactions_logs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: commandes_reference_unique_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX commandes_reference_unique_idx ON public.commandes USING btree (reference_unique);


--
-- Name: commandes_reference_unique_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX commandes_reference_unique_key ON public.commandes USING btree (reference_unique);


--
-- Name: commandes_statut_commande_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX commandes_statut_commande_idx ON public.commandes USING btree (statut_commande);


--
-- Name: commandes_user_id_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX commandes_user_id_idx ON public.commandes USING btree (user_id);


--
-- Name: operateurs_nom_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX operateurs_nom_key ON public.operateurs USING btree (nom);


--
-- Name: taches_ussd_priorite_statut_execution_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX taches_ussd_priorite_statut_execution_idx ON public.taches_ussd USING btree (priorite, statut_execution);


--
-- Name: telephones_executeurs_numero_telephone_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX telephones_executeurs_numero_telephone_key ON public.telephones_executeurs USING btree (numero_telephone);


--
-- Name: telephones_executeurs_token_auth_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX telephones_executeurs_token_auth_key ON public.telephones_executeurs USING btree (token_auth);


--
-- Name: transactions_logs_created_at_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX transactions_logs_created_at_idx ON public.transactions_logs USING btree (created_at);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_telephone_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX users_telephone_key ON public.users USING btree (telephone);


--
-- Name: commandes commandes_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.commandes
    ADD CONSTRAINT commandes_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services_catalogue(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: commandes commandes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.commandes
    ADD CONSTRAINT commandes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: preuves_paiement preuves_paiement_commande_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.preuves_paiement
    ADD CONSTRAINT preuves_paiement_commande_id_fkey FOREIGN KEY (commande_id) REFERENCES public.commandes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: preuves_paiement preuves_paiement_valide_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.preuves_paiement
    ADD CONSTRAINT preuves_paiement_valide_par_fkey FOREIGN KEY (valide_par) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: services_catalogue services_catalogue_operateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.services_catalogue
    ADD CONSTRAINT services_catalogue_operateur_id_fkey FOREIGN KEY (operateur_id) REFERENCES public.operateurs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: taches_ussd taches_ussd_commande_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.taches_ussd
    ADD CONSTRAINT taches_ussd_commande_id_fkey FOREIGN KEY (commande_id) REFERENCES public.commandes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: taches_ussd taches_ussd_telephone_executeur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.taches_ussd
    ADD CONSTRAINT taches_ussd_telephone_executeur_id_fkey FOREIGN KEY (telephone_executeur_id) REFERENCES public.telephones_executeurs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: telephones_executeurs telephones_executeurs_operateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.telephones_executeurs
    ADD CONSTRAINT telephones_executeurs_operateur_id_fkey FOREIGN KEY (operateur_id) REFERENCES public.operateurs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transactions_logs transactions_logs_commande_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.transactions_logs
    ADD CONSTRAINT transactions_logs_commande_id_fkey FOREIGN KEY (commande_id) REFERENCES public.commandes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions_logs transactions_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.transactions_logs
    ADD CONSTRAINT transactions_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict waGw4ao9bPgsgW0Gd6T9a8nFcF2h5oXBCQ5UeMZChy9VpYevMP5DL7eqkpd6ERq

