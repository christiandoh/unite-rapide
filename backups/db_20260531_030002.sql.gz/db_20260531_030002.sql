--
-- PostgreSQL database dump
--

\restrict cRJHwqwBxgB31OUn9T6ZMJxcxxnIfvC7hDHygz5PH2NZ1Wo90UkpOyeuyWbsWhI

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."Role" AS ENUM (
    'user',
    'admin'
);


ALTER TYPE public."Role" OWNER TO ussd_admin;

--
-- Name: SeveriteLog; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."SeveriteLog" AS ENUM (
    'debug',
    'info',
    'warning',
    'error',
    'critical'
);


ALTER TYPE public."SeveriteLog" OWNER TO ussd_admin;

--
-- Name: StatutCommande; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutCommande" AS ENUM (
    'en_attente_paiement',
    'paiement_soumis',
    'paiement_valide',
    'paiement_rejete',
    'en_cours_execution',
    'execute',
    'echoue',
    'rembourse'
);


ALTER TYPE public."StatutCommande" OWNER TO ussd_admin;

--
-- Name: StatutExecution; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutExecution" AS ENUM (
    'en_attente',
    'en_cours',
    'reussi',
    'echoue',
    'timeout',
    'annule'
);


ALTER TYPE public."StatutExecution" OWNER TO ussd_admin;

--
-- Name: StatutPhone; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutPhone" AS ENUM (
    'en_ligne',
    'hors_ligne',
    'occupe',
    'maintenance',
    'erreur'
);


ALTER TYPE public."StatutPhone" OWNER TO ussd_admin;

--
-- Name: StatutUser; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutUser" AS ENUM (
    'actif',
    'suspendu',
    'banni'
);


ALTER TYPE public."StatutUser" OWNER TO ussd_admin;

--
-- Name: StatutValidation; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."StatutValidation" AS ENUM (
    'en_attente',
    'valide_auto',
    'valide_manuel',
    'rejete',
    'a_reviser'
);


ALTER TYPE public."StatutValidation" OWNER TO ussd_admin;

--
-- Name: TypeService; Type: TYPE; Schema: public; Owner: ussd_admin
--

CREATE TYPE public."TypeService" AS ENUM (
    'forfait_internet',
    'credit_appel',
    'forfait_mixte',
    'abonnement'
);


ALTER TYPE public."TypeService" OWNER TO ussd_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO ussd_admin;

--
-- Name: commandes; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.commandes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    service_id uuid NOT NULL,
    telephone_beneficiaire character varying(20) NOT NULL,
    reference_unique character varying(20) NOT NULL,
    montant numeric(10,2) NOT NULL,
    lien_paiement_wave text NOT NULL,
    statut_commande character varying(30) DEFAULT 'en_attente_paiement'::character varying NOT NULL,
    date_expiration_paiement timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.commandes OWNER TO ussd_admin;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    titre character varying(255) NOT NULL,
    message text NOT NULL,
    lu boolean DEFAULT false NOT NULL,
    donnees jsonb DEFAULT '{}'::jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notifications OWNER TO ussd_admin;

--
-- Name: operateurs; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.operateurs (
    id uuid NOT NULL,
    nom character varying(50) NOT NULL,
    code_pays character varying(5) DEFAULT '+225'::character varying NOT NULL,
    prefixe character varying(10),
    logo_url character varying(255),
    actif boolean DEFAULT true NOT NULL
);


ALTER TABLE public.operateurs OWNER TO ussd_admin;

--
-- Name: preuves_paiement; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.preuves_paiement (
    id uuid NOT NULL,
    commande_id uuid NOT NULL,
    image_originale_url text NOT NULL,
    image_traitee_url text,
    donnees_extraites jsonb,
    score_confiance numeric(5,2),
    flags_fraude jsonb DEFAULT '[]'::jsonb,
    statut_validation character varying(30) DEFAULT 'en_attente'::character varying NOT NULL,
    valide_par uuid,
    commentaire_validation text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.preuves_paiement OWNER TO ussd_admin;

--
-- Name: services_catalogue; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.services_catalogue (
    id uuid NOT NULL,
    operateur_id uuid NOT NULL,
    nom character varying(255) NOT NULL,
    description text,
    type_service character varying(50) NOT NULL,
    code_ussd character varying(100) NOT NULL,
    sequence_ussd jsonb NOT NULL,
    montant_wave numeric(10,2) NOT NULL,
    volume_data character varying(50),
    duree_validite character varying(50),
    temps_execution_moyen integer DEFAULT 30 NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    populaire boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.services_catalogue OWNER TO ussd_admin;

--
-- Name: taches_ussd; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.taches_ussd (
    id uuid NOT NULL,
    commande_id uuid NOT NULL,
    telephone_executeur_id uuid,
    priorite integer DEFAULT 5 NOT NULL,
    statut_execution character varying(30) DEFAULT 'en_attente'::character varying NOT NULL,
    logs_execution jsonb DEFAULT '[]'::jsonb,
    nombre_tentatives integer DEFAULT 0 NOT NULL,
    tentative_max integer DEFAULT 3 NOT NULL,
    date_debut_execution timestamp(3) without time zone,
    date_fin_execution timestamp(3) without time zone,
    message_erreur text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.taches_ussd OWNER TO ussd_admin;

--
-- Name: telephones_executeurs; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.telephones_executeurs (
    id uuid NOT NULL,
    nom_appareil character varying(100) NOT NULL,
    modele character varying(100),
    numero_telephone character varying(20) NOT NULL,
    operateur_id uuid NOT NULL,
    token_auth character varying(255) NOT NULL,
    statut character varying(20) DEFAULT 'hors_ligne'::character varying NOT NULL,
    niveau_batterie integer,
    force_signal integer,
    version_app character varying(20),
    derniere_connexion timestamp(3) without time zone,
    ip_address character varying(45),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.telephones_executeurs OWNER TO ussd_admin;

--
-- Name: transactions_logs; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.transactions_logs (
    id uuid NOT NULL,
    type_evenement character varying(50) NOT NULL,
    severite character varying(20) DEFAULT 'info'::character varying NOT NULL,
    details jsonb DEFAULT '{}'::jsonb,
    user_id uuid,
    commande_id uuid,
    adresse_ip character varying(45),
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transactions_logs OWNER TO ussd_admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: ussd_admin
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    nom character varying(100) NOT NULL,
    prenom character varying(100),
    telephone character varying(20) NOT NULL,
    email character varying(255),
    mot_de_passe_hash character varying(255) NOT NULL,
    email_verifie boolean DEFAULT false NOT NULL,
    telephone_verifie boolean DEFAULT false NOT NULL,
    statut character varying(20) DEFAULT 'actif'::character varying NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying NOT NULL,
    derniere_connexion timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO ussd_admin;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.


--
-- Data for Name: commandes; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.commandes (id, user_id, service_id, telephone_beneficiaire, reference_unique, montant, lien_paiement_wave, statut_commande, date_expiration_paiement, created_at, updated_at) FROM stdin;
4d66a377-0af9-4fcc-9a21-5666e2dd7fee	7747df8f-c33a-4bc1-aeb3-16596ca6d203	ba25bbf1-4c64-4d97-b3bc-7777e3a927eb	0711118582	USSD-20260529-6VSB2Q	5000.00	https://pay.wave.com/m/M_ci_vaaCd-Y6Joie/c/ci/?amount=5000	paiement_soumis	2026-05-30 01:36:12.367	2026-05-30 01:21:12.37	2026-05-30 01:30:18.813
75c56d84-32c3-43c1-ad86-5977c9278a69	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba25bbf1-4c64-4d97-b3bc-7777e3a927eb	0103961828	USSD-20260529-NS5XQD	5000.00	https://pay.wave.com/m/M_ci_vaaCd-Y6Joie/c/ci/?amount=5000	en_attente_paiement	2026-05-30 01:52:32.399	2026-05-30 01:37:32.4	2026-05-30 01:37:32.4
d3222401-4ebf-49fd-b1e5-b97d3f3a8cd5	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba25bbf1-4c64-4d97-b3bc-7777e3a927eb	0103961828	USSD-20260529-29S3YH	5000.00	https://pay.wave.com/m/M_ci_vaaCd-Y6Joie/c/ci/?amount=5000	paiement_soumis	2026-05-30 01:53:42.786	2026-05-30 01:38:42.788	2026-05-30 01:39:04.96
7c5ced3e-ebc4-46a5-ab13-970558bdcb05	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba88344b-e1ad-4820-b13a-7b1632bcc7e1	0787654523	USSD-20260530-KDL1ZI	500.00		echoue	2026-05-30 04:12:49.514	2026-05-30 03:57:49.516	2026-05-30 03:57:54.656
42f2f195-afd8-4caa-882c-99b08679ec42	76cc2be1-3c40-4b33-b7c1-f63976840d82	ca365202-e053-4bbd-b555-d88c3b34fbb1	0711118582	USSD-20260529-WK75XL	2000.00	https://pay.wave.com/m/M_ci_vaaCd-Y6Joie/c/ci/?amount=2000	echoue	2026-05-30 03:09:58.19	2026-05-30 02:54:58.192	2026-05-30 02:56:34.184
27c2a459-526f-4945-9742-e929ed03adc6	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba25bbf1-4c64-4d97-b3bc-7777e3a927eb	0711118582	USSD-20260529-CMV4N5	5000.00	https://pay.wave.com/m/M_ci_vaaCd-Y6Joie/c/ci/?amount=5000	echoue	2026-05-30 03:23:50.039	2026-05-30 03:08:50.041	2026-05-30 03:09:45.978
b8e91a92-95f6-4c32-8313-b0a6a3bf1dc4	76cc2be1-3c40-4b33-b7c1-f63976840d82	b3f9862c-b05d-4a6b-b438-20016a204217	4739832	USSD-20260530-6W50CO	500.00		echoue	2026-05-30 06:37:31.499	2026-05-30 06:22:31.501	2026-05-30 06:22:33.122
fd6505b9-1850-4124-b5c9-e3af0d859540	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba25bbf1-4c64-4d97-b3bc-7777e3a927eb	0711118582	USSD-20260530-TJTX34	5000.00		echoue	2026-05-30 03:35:47.686	2026-05-30 03:20:47.688	2026-05-30 03:20:53.957
94b2a092-eacf-4b04-a6c4-945625e8deb3	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba25bbf1-4c64-4d97-b3bc-7777e3a927eb	0711118582	USSD-20260529-X141U2	5000.00	https://pay.wave.com/m/M_ci_vaaCd-Y6Joie/c/ci/?amount=5000	echoue	2026-05-30 02:14:12.491	2026-05-30 01:59:12.492	2026-05-30 02:07:39.145
c81e63a4-5f0d-44a4-8fda-d8640e17a49a	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba88344b-e1ad-4820-b13a-7b1632bcc7e1	0711118582	USSD-20260530-1ZNRIB	500.00		echoue	2026-05-30 04:00:24.73	2026-05-30 03:45:24.732	2026-05-30 03:45:24.732
2c7c1ee7-6998-41e9-b558-93f65223af30	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba88344b-e1ad-4820-b13a-7b1632bcc7e1	0711118583	USSD-20260530-KB5T52	500.00		echoue	2026-05-30 04:02:30.922	2026-05-30 03:47:30.924	2026-05-30 03:47:30.924
286e3a3a-7758-431f-94fc-527762f85ea1	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba25bbf1-4c64-4d97-b3bc-7777e3a927eb	0711118583	USSD-20260530-XOMTOB	5000.00		echoue	2026-05-30 04:05:23.504	2026-05-30 03:50:23.506	2026-05-30 03:50:23.867
317a1804-c544-4128-b41c-8b301273eb7f	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba88344b-e1ad-4820-b13a-7b1632bcc7e1	0719125623	USSD-20260530-SMECOH	500.00		echoue	2026-05-30 04:14:27.617	2026-05-30 03:59:27.618	2026-05-30 03:59:31.456
337db501-b845-45b9-a3f4-49fc8f730d98	76cc2be1-3c40-4b33-b7c1-f63976840d82	b3f9862c-b05d-4a6b-b438-20016a204217	4739832	USSD-20260530-GHRKHH	500.00		echoue	2026-05-30 06:38:03.869	2026-05-30 06:23:03.87	2026-05-30 06:23:04.925
6fc22804-f73c-42ed-bd21-aa154f8ca9bd	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba88344b-e1ad-4820-b13a-7b1632bcc7e1	0719125623	USSD-20260530-3WM8LF	500.00		echoue	2026-05-30 04:15:26.481	2026-05-30 04:00:26.483	2026-05-30 04:00:29.452
ac01dd5d-1b41-4c97-b41f-51887094cd1c	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba88344b-e1ad-4820-b13a-7b1632bcc7e1	0719125623	USSD-20260530-6QNM3H	500.00		echoue	2026-05-30 04:17:02.866	2026-05-30 04:02:02.869	2026-05-30 04:02:06.778
2785a818-cbec-4115-8ea2-024b25748775	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba88344b-e1ad-4820-b13a-7b1632bcc7e1	0783448390	USSD-20260530-TXCX8V	500.00		echoue	2026-05-30 04:45:00.489	2026-05-30 04:30:00.492	2026-05-30 04:30:01.921
74f0f5c1-c02e-4954-ad2e-dbf7b74a9d4f	76cc2be1-3c40-4b33-b7c1-f63976840d82	ba88344b-e1ad-4820-b13a-7b1632bcc7e1	0783448390	USSD-20260530-DWIRG9	500.00		echoue	2026-05-30 04:45:47.826	2026-05-30 04:30:47.827	2026-05-30 04:30:48.759
a1a4d32f-e352-4a3b-9235-2561d3b1546e	76cc2be1-3c40-4b33-b7c1-f63976840d82	b3f9862c-b05d-4a6b-b438-20016a204217	0787890934	USSD-20260530-MBZB8E	500.00		echoue	2026-05-30 04:57:42.77	2026-05-30 04:42:42.773	2026-05-30 04:42:43.999
92aa24ce-a1c7-464a-9531-23c650334097	76cc2be1-3c40-4b33-b7c1-f63976840d82	b3f9862c-b05d-4a6b-b438-20016a204217	0711118584	USSD-20260530-J8UF8Q	500.00		echoue	2026-05-30 05:13:38.746	2026-05-30 04:58:38.748	2026-05-30 04:59:10.522
6b4e85e6-5473-4bfd-90bf-df30e1b541e4	76cc2be1-3c40-4b33-b7c1-f63976840d82	b3f9862c-b05d-4a6b-b438-20016a204217	0711118584	USSD-20260530-JICR69	500.00		echoue	2026-05-30 05:14:08.916	2026-05-30 04:59:08.918	2026-05-30 04:59:11.72
ec6be34b-f305-4907-b01b-cdb491f098d5	76cc2be1-3c40-4b33-b7c1-f63976840d82	b3f9862c-b05d-4a6b-b438-20016a204217	0711118583	USSD-20260530-RBXFXW	500.00		echoue	2026-05-30 06:39:44.601	2026-05-30 06:24:44.603	2026-05-30 06:24:45.791
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.notifications (id, user_id, type, titre, message, lu, donnees, created_at) FROM stdin;
\.


--
-- Data for Name: operateurs; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.operateurs (id, nom, code_pays, prefixe, logo_url, actif) FROM stdin;
a3ea5aef-1c8f-4714-8db6-9269f20a22c5	Orange	+225	07	\N	t
c770e2b3-68a6-4391-a701-8a5fc12bc905	Moov	+225	01	\N	t
a4c25ba6-a6a6-4e90-bba7-4053a704b4aa	MTN	+225	05	\N	t
\.


--
-- Data for Name: preuves_paiement; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.preuves_paiement (id, commande_id, image_originale_url, image_traitee_url, donnees_extraites, score_confiance, flags_fraude, statut_validation, valide_par, commentaire_validation, created_at) FROM stdin;
a5c91430-0552-445b-ada8-def22574887d	4d66a377-0af9-4fcc-9a21-5666e2dd7fee	/uploads/proofs/624c3992-0c12-4a9c-a6da-34828fe9075d.jpg	\N	\N	\N	[]	en_attente	\N	\N	2026-05-30 01:30:19.136
df15d64a-aac4-4122-ada8-b0763552af6c	d3222401-4ebf-49fd-b1e5-b97d3f3a8cd5	/uploads/proofs/931ed440-f37d-434a-aa02-a1fb162f5ea0.jpg	\N	\N	\N	[]	en_attente	\N	\N	2026-05-30 01:39:05.046
200e85fb-ea26-4a68-bf57-d962d2ab4ae2	94b2a092-eacf-4b04-a6c4-945625e8deb3	/uploads/proofs/aebe197a-8b98-4a66-896e-216487d520c5.jpg	\N	\N	\N	[]	valide_manuel	76cc2be1-3c40-4b33-b7c1-f63976840d82	Test validation admin	2026-05-30 02:06:29.091
fabecf83-746d-4b2d-9839-8ef0f4cdfef4	42f2f195-afd8-4caa-882c-99b08679ec42	/uploads/proofs/7132e787-a59f-4ef2-b997-36bee2e497e1.jpg	\N	\N	\N	[]	valide_manuel	76cc2be1-3c40-4b33-b7c1-f63976840d82	\N	2026-05-30 02:55:56.997
7a6a127d-43ed-4a59-9060-7f1dec224384	27c2a459-526f-4945-9742-e929ed03adc6	/uploads/proofs/efb0b272-235c-4e30-9969-53232287e021.jpg	\N	\N	\N	[]	valide_manuel	76cc2be1-3c40-4b33-b7c1-f63976840d82	\N	2026-05-30 03:09:12.141
\.


--
-- Data for Name: services_catalogue; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.services_catalogue (id, operateur_id, nom, description, type_service, code_ussd, sequence_ussd, montant_wave, volume_data, duree_validite, temps_execution_moyen, actif, populaire, created_at) FROM stdin;
746d5ec4-f572-4172-b1a5-e6756fafb477	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	Internet 2Go	\N	forfait_internet	*143*1#	["1", "2", "1"]	2000.00	2Go	7 jours	30	t	t	2026-05-29 21:08:33.333
919cceea-d221-4bbd-8c1c-4b71f7ec961b	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	Internet 10Go	\N	forfait_internet	*143*1#	["1", "5", "1"]	10000.00	10Go	30 jours	30	t	t	2026-05-29 21:08:33.333
e51de04d-7382-4a8f-8c96-cab810bc4fa4	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	Crédit 5000F	\N	credit_appel	*144*1#	["1", "3"]	5000.00	\N	\N	30	t	t	2026-05-29 21:08:33.333
b68d1187-714a-484d-b649-9a7d2f12d137	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	Internet 500Mo	\N	forfait_internet	*143*1#	["1", "1", "1"]	500.00	500Mo	24 heures	30	t	f	2026-05-29 21:08:33.333
b17717b5-fe6f-414d-bc8c-5569ae6ae571	a4c25ba6-a6a6-4e90-bba7-4053a704b4aa	Forfait 3Go	\N	forfait_internet	*133*1#	["1", "3", "2"]	3000.00	3Go	14 jours	30	t	t	2026-05-29 21:08:33.333
9f3c3ceb-f109-463e-b9a5-c75a2e638ecc	a4c25ba6-a6a6-4e90-bba7-4053a704b4aa	Crédit 10000F	\N	credit_appel	*136*1#	["1", "5"]	10000.00	\N	\N	30	t	t	2026-05-29 21:08:33.333
239ea23b-d97e-4b3b-8ee0-801cf4b3a72b	a4c25ba6-a6a6-4e90-bba7-4053a704b4aa	Forfait 1Go	\N	forfait_internet	*133*1#	["1", "1", "1"]	1000.00	1Go	7 jours	30	t	f	2026-05-29 21:08:33.333
01e0b6aa-a4ba-4f94-bcda-d7104ee97c69	c770e2b3-68a6-4391-a701-8a5fc12bc905	Forfait 2Go	\N	forfait_internet	*155#	["9", "4", "1", "5", "1", "0003"]	2000.00	2Go	7 jours	30	t	f	2026-05-29 21:08:33.333
8388da29-217c-4667-86a7-912c67565228	c770e2b3-68a6-4391-a701-8a5fc12bc905	Crédit 2000F	\N	credit_appel	*126*1#	["1", "2"]	2000.00	\N	\N	30	t	f	2026-05-29 21:08:33.333
ca365202-e053-4bbd-b555-d88c3b34fbb1	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	Internet 2Go	\N	forfait_internet	*143*1#	["1", "2", "1"]	2000.00	2Go	7 jours	30	t	t	2026-05-29 21:13:54.918
af2c8768-e716-4d92-9a83-33e9864ce94d	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	Internet 10Go	\N	forfait_internet	*143*1#	["1", "5", "1"]	10000.00	10Go	30 jours	30	t	t	2026-05-29 21:13:54.918
8ade66ef-c27f-4340-bc7a-dbece394883a	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	Internet 500Mo	\N	forfait_internet	*143*1#	["1", "1", "1"]	500.00	500Mo	24 heures	30	t	f	2026-05-29 21:13:54.918
550e2a89-8207-47b1-b759-a79961963e7b	a4c25ba6-a6a6-4e90-bba7-4053a704b4aa	Forfait 3Go	\N	forfait_internet	*133*1#	["1", "3", "2"]	3000.00	3Go	14 jours	30	t	t	2026-05-29 21:13:54.918
be90bea5-ad9a-4edc-bdaa-85f5396701e0	a4c25ba6-a6a6-4e90-bba7-4053a704b4aa	Crédit 10000F	\N	credit_appel	*136*1#	["1", "5"]	10000.00	\N	\N	30	t	t	2026-05-29 21:13:54.918
b1517e94-9c7e-4450-9173-67528f5a3bc6	a4c25ba6-a6a6-4e90-bba7-4053a704b4aa	Forfait 1Go	\N	forfait_internet	*133*1#	["1", "1", "1"]	1000.00	1Go	7 jours	30	t	f	2026-05-29 21:13:54.918
50d0d4bf-3d56-41df-83c4-5c7fd6b1aae1	c770e2b3-68a6-4391-a701-8a5fc12bc905	Forfait 2Go	\N	forfait_internet	*155#	["9", "4", "1", "5", "1", "0003"]	2000.00	2Go	7 jours	30	t	f	2026-05-29 21:13:54.918
be12a603-cd21-407b-b72b-00cbb188acaf	c770e2b3-68a6-4391-a701-8a5fc12bc905	Crédit 2000F	\N	credit_appel	*126*1#	["1", "2"]	2000.00	\N	\N	30	t	f	2026-05-29 21:13:54.918
ba25bbf1-4c64-4d97-b3bc-7777e3a927eb	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	SOLDE	\N	credit_appel	#144*8*1*8582#	["8", "1", "8582"]	5000.00	COMPTE	50 JOURS	30	t	t	2026-05-29 21:13:54.918
ba88344b-e1ad-4820-b13a-7b1632bcc7e1	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	SOLDE ORANGE	\N	credit_appel	#144*1*1*{numero}*{montant}*1*8582#	[]	500.00	COMPTE		30	t	t	2026-05-30 03:45:09.711
b3f9862c-b05d-4a6b-b438-20016a204217	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	Internet  1,5GO	\N	forfait_internet	#111*1*2*2*3*1*8582*{numero}#	[]	500.00	1,5GO	7 jours	30	t	t	2026-05-30 04:37:04.738
\.


--
-- Data for Name: taches_ussd; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.taches_ussd (id, commande_id, telephone_executeur_id, priorite, statut_execution, logs_execution, nombre_tentatives, tentative_max, date_debut_execution, date_fin_execution, message_erreur, created_at) FROM stdin;
52a63e1d-a8ca-4aee-a868-5366e1384c35	94b2a092-eacf-4b04-a6c4-945625e8deb3	\N	5	en_attente	[]	0	3	\N	\N	En attente telephone disponible	2026-05-30 02:07:39.188
554bddb7-81fb-49a6-aea7-fb54be6e68b5	42f2f195-afd8-4caa-882c-99b08679ec42	95676964-a419-4448-b614-dbd85b1ab244	5	echoue	[{"action": "echoue", "message": "Aucun champ de saisie trouvé", "timestamp": "2026-05-30T02:56:34.023Z"}]	0	3	2026-05-30 02:55:57.757	2026-05-30 02:56:34.023	Aucun champ de saisie trouvé	2026-05-30 02:55:57.643
8e23cea3-6d1c-480f-8164-8a6850fde17a	a1a4d32f-e352-4a3b-9235-2561d3b1546e	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T04:42:43.935Z"}]	0	3	2026-05-30 04:42:42.949	2026-05-30 04:42:43.935	Format de reponse invalide	2026-05-30 04:42:42.858
da637162-612a-44ff-9622-b77c8e3637a7	27c2a459-526f-4945-9742-e929ed03adc6	95676964-a419-4448-b614-dbd85b1ab244	5	echoue	[{"action": "echoue", "message": "Délai dépassé (30 s)", "timestamp": "2026-05-30T03:09:45.905Z"}]	0	3	2026-05-30 03:09:12.396	2026-05-30 03:09:45.905	Délai dépassé (30 s)	2026-05-30 03:09:12.307
86ed7af4-288b-4406-a1d0-cd7e7294e673	317a1804-c544-4128-b41c-8b301273eb7f	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T03:59:31.372Z"}]	0	3	2026-05-30 03:59:27.788	2026-05-30 03:59:31.372	Format de reponse invalide	2026-05-30 03:59:27.709
a238b55f-592b-48f8-99fb-74bf2dc62a0a	fd6505b9-1850-4124-b5c9-e3af0d859540	95676964-a419-4448-b614-dbd85b1ab244	5	echoue	[{"action": "echoue", "message": "Aucun champ de saisie trouvé", "timestamp": "2026-05-30T03:20:53.923Z"}]	0	3	2026-05-30 03:20:48.365	2026-05-30 03:20:53.923	Aucun champ de saisie trouvé	2026-05-30 03:20:47.74
878e3d6f-4c0a-4fc2-9e54-54fa5617480a	c81e63a4-5f0d-44a4-8fda-d8640e17a49a	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "debut", "timestamp": "2026-05-30T03:45:25.302Z"}]	0	3	2026-05-30 03:45:25.302	\N	Telephone hors ligne - pas de reponse	2026-05-30 03:45:24.784
55e12434-2c5a-44eb-87a5-0b53d22fea78	2c7c1ee7-6998-41e9-b558-93f65223af30	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "debut", "timestamp": "2026-05-30T03:47:31.097Z"}]	0	3	2026-05-30 03:47:31.097	\N	Telephone hors ligne - pas de reponse	2026-05-30 03:47:31.01
6972b93c-b053-4228-a854-d39e1b37a441	286e3a3a-7758-431f-94fc-527762f85ea1	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "debut", "timestamp": "2026-05-30T03:50:23.810Z"}]	0	3	2026-05-30 03:50:23.81	\N	Telephone hors ligne - pas de reponse	2026-05-30 03:50:23.595
5fb697c9-e64a-42a6-a51a-33d3e5a11697	7c5ced3e-ebc4-46a5-ab13-970558bdcb05	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T03:57:54.582Z"}]	0	3	2026-05-30 03:57:49.71	2026-05-30 03:57:54.582	Format de reponse invalide	2026-05-30 03:57:49.61
47a05d0d-d3b5-4de3-bda2-140b657fcd9b	6fc22804-f73c-42ed-bd21-aa154f8ca9bd	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T04:00:29.339Z"}]	0	3	2026-05-30 04:00:26.633	2026-05-30 04:00:29.339	Format de reponse invalide	2026-05-30 04:00:26.543
0a60e87c-d8bb-4ecb-b0c0-d984b130f600	ac01dd5d-1b41-4c97-b41f-51887094cd1c	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T04:02:06.725Z"}]	0	3	2026-05-30 04:02:03.005	2026-05-30 04:02:06.725	Format de reponse invalide	2026-05-30 04:02:02.928
8f296f9f-4670-426f-b504-4295b4822d2c	2785a818-cbec-4115-8ea2-024b25748775	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T04:30:01.837Z"}]	0	3	2026-05-30 04:30:00.7	2026-05-30 04:30:01.837	Format de reponse invalide	2026-05-30 04:30:00.606
23d7afc9-2812-4717-8ed5-7a1babed42d2	74f0f5c1-c02e-4954-ad2e-dbf7b74a9d4f	c4050780-0ba7-485c-a560-adf91a16dde1	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T04:30:48.682Z"}]	0	3	2026-05-30 04:30:48.009	2026-05-30 04:30:48.682	Format de reponse invalide	2026-05-30 04:30:47.926
44dd8882-fded-43e8-8bf9-463b7422d269	92aa24ce-a1c7-464a-9531-23c650334097	95676964-a419-4448-b614-dbd85b1ab244	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T04:59:10.420Z"}]	0	3	2026-05-30 04:59:09	2026-05-30 04:59:10.42	Format de reponse invalide	2026-05-30 04:58:38.805
52c7edff-cc75-4858-ab1c-03a6676f2bcc	6b4e85e6-5473-4bfd-90bf-df30e1b541e4	95676964-a419-4448-b614-dbd85b1ab244	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T04:59:11.649Z"}]	0	3	2026-05-30 04:59:09.18	2026-05-30 04:59:11.649	Format de reponse invalide	2026-05-30 04:59:08.972
1e8b9153-ec46-43f8-9494-77dd13bae08d	b8e91a92-95f6-4c32-8313-b0a6a3bf1dc4	95676964-a419-4448-b614-dbd85b1ab244	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T06:22:33.081Z"}]	0	3	2026-05-30 06:22:31.646	2026-05-30 06:22:33.081	Format de reponse invalide	2026-05-30 06:22:31.557
60c694d2-75bd-4144-84d7-40888be3fdfb	337db501-b845-45b9-a3f4-49fc8f730d98	95676964-a419-4448-b614-dbd85b1ab244	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T06:23:04.872Z"}]	0	3	2026-05-30 06:23:04.099	2026-05-30 06:23:04.872	Format de reponse invalide	2026-05-30 06:23:04.009
52eb1e14-ea95-4138-84be-bd57e97e0486	ec6be34b-f305-4907-b01b-cdb491f098d5	95676964-a419-4448-b614-dbd85b1ab244	5	echoue	[{"action": "echoue", "message": "Format de reponse invalide", "timestamp": "2026-05-30T06:24:45.730Z"}]	0	3	2026-05-30 06:24:44.774	2026-05-30 06:24:45.729	Format de reponse invalide	2026-05-30 06:24:44.702
\.


--
-- Data for Name: telephones_executeurs; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.telephones_executeurs (id, nom_appareil, modele, numero_telephone, operateur_id, token_auth, statut, niveau_batterie, force_signal, version_app, derniere_connexion, ip_address, created_at) FROM stdin;
95676964-a419-4448-b614-dbd85b1ab244	OMCI02	Android	0711118583	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	phone-omci02-mprr9bs1	en_ligne	\N	\N	\N	\N	\N	2026-05-30 02:52:20.068
57fbadec-f68a-41a8-9ae4-da63279a1e6b	MVCI01	Android	0103961828	c770e2b3-68a6-4391-a701-8a5fc12bc905	phone-mvci01-mprsggbk	hors_ligne	\N	\N	\N	\N	\N	2026-05-30 03:25:52.161
c4050780-0ba7-485c-a560-adf91a16dde1	OMCI01	Android	0711118582	a3ea5aef-1c8f-4714-8db6-9269f20a22c5	phone-omci01-mprjwaqk	en_ligne	\N	\N	\N	\N	\N	2026-05-29 23:26:14.878
\.


--
-- Data for Name: transactions_logs; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.transactions_logs (id, type_evenement, severite, details, user_id, commande_id, adresse_ip, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ussd_admin
--

COPY public.users (id, nom, prenom, telephone, email, mot_de_passe_hash, email_verifie, telephone_verifie, statut, role, derniere_connexion, created_at, updated_at) FROM stdin;
7747df8f-c33a-4bc1-aeb3-16596ca6d203	lah	nundo	0103961828	\N	$2b$12$O21ofWAGjpvYEAgz1WjBYuilJXvd.UA8UXhvfRJ/fUxjB4KrELQ.e	f	f	actif	user	\N	2026-05-30 01:20:05.964	2026-05-30 01:20:05.964
76cc2be1-3c40-4b33-b7c1-f63976840d82	Admin	Super	0711118582	christiandoh29@gmail.com	$2b$12$RdnZqvy0F1k5VNbCbc9xPef0rbKVA16I8h/8YyzRvNmINkDvD9bM.	f	f	actif	admin	2026-05-30 13:15:00.099	2026-05-29 21:13:54.527	2026-05-30 13:15:00.101
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: commandes commandes_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.commandes
    ADD CONSTRAINT commandes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: operateurs operateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.operateurs
    ADD CONSTRAINT operateurs_pkey PRIMARY KEY (id);


--
-- Name: preuves_paiement preuves_paiement_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.preuves_paiement
    ADD CONSTRAINT preuves_paiement_pkey PRIMARY KEY (id);


--
-- Name: services_catalogue services_catalogue_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.services_catalogue
    ADD CONSTRAINT services_catalogue_pkey PRIMARY KEY (id);


--
-- Name: taches_ussd taches_ussd_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.taches_ussd
    ADD CONSTRAINT taches_ussd_pkey PRIMARY KEY (id);


--
-- Name: telephones_executeurs telephones_executeurs_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.telephones_executeurs
    ADD CONSTRAINT telephones_executeurs_pkey PRIMARY KEY (id);


--
-- Name: transactions_logs transactions_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.transactions_logs
    ADD CONSTRAINT transactions_logs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: commandes_reference_unique_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX commandes_reference_unique_idx ON public.commandes USING btree (reference_unique);


--
-- Name: commandes_reference_unique_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX commandes_reference_unique_key ON public.commandes USING btree (reference_unique);


--
-- Name: commandes_statut_commande_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX commandes_statut_commande_idx ON public.commandes USING btree (statut_commande);


--
-- Name: commandes_user_id_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX commandes_user_id_idx ON public.commandes USING btree (user_id);


--
-- Name: operateurs_nom_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX operateurs_nom_key ON public.operateurs USING btree (nom);


--
-- Name: taches_ussd_priorite_statut_execution_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX taches_ussd_priorite_statut_execution_idx ON public.taches_ussd USING btree (priorite, statut_execution);


--
-- Name: telephones_executeurs_numero_telephone_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX telephones_executeurs_numero_telephone_key ON public.telephones_executeurs USING btree (numero_telephone);


--
-- Name: telephones_executeurs_token_auth_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX telephones_executeurs_token_auth_key ON public.telephones_executeurs USING btree (token_auth);


--
-- Name: transactions_logs_created_at_idx; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE INDEX transactions_logs_created_at_idx ON public.transactions_logs USING btree (created_at);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_telephone_key; Type: INDEX; Schema: public; Owner: ussd_admin
--

CREATE UNIQUE INDEX users_telephone_key ON public.users USING btree (telephone);


--
-- Name: commandes commandes_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.commandes
    ADD CONSTRAINT commandes_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services_catalogue(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: commandes commandes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.commandes
    ADD CONSTRAINT commandes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: preuves_paiement preuves_paiement_commande_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.preuves_paiement
    ADD CONSTRAINT preuves_paiement_commande_id_fkey FOREIGN KEY (commande_id) REFERENCES public.commandes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: preuves_paiement preuves_paiement_valide_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.preuves_paiement
    ADD CONSTRAINT preuves_paiement_valide_par_fkey FOREIGN KEY (valide_par) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: services_catalogue services_catalogue_operateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.services_catalogue
    ADD CONSTRAINT services_catalogue_operateur_id_fkey FOREIGN KEY (operateur_id) REFERENCES public.operateurs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: taches_ussd taches_ussd_commande_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.taches_ussd
    ADD CONSTRAINT taches_ussd_commande_id_fkey FOREIGN KEY (commande_id) REFERENCES public.commandes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: taches_ussd taches_ussd_telephone_executeur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.taches_ussd
    ADD CONSTRAINT taches_ussd_telephone_executeur_id_fkey FOREIGN KEY (telephone_executeur_id) REFERENCES public.telephones_executeurs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: telephones_executeurs telephones_executeurs_operateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.telephones_executeurs
    ADD CONSTRAINT telephones_executeurs_operateur_id_fkey FOREIGN KEY (operateur_id) REFERENCES public.operateurs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transactions_logs transactions_logs_commande_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.transactions_logs
    ADD CONSTRAINT transactions_logs_commande_id_fkey FOREIGN KEY (commande_id) REFERENCES public.commandes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions_logs transactions_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ussd_admin
--

ALTER TABLE ONLY public.transactions_logs
    ADD CONSTRAINT transactions_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict cRJHwqwBxgB31OUn9T6ZMJxcxxnIfvC7hDHygz5PH2NZ1Wo90UkpOyeuyWbsWhI

